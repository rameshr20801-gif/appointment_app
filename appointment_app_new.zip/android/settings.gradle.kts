pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }

    // Kotlin plugin version upgraded to match Stripe Android (= Kotlin 2.1.x)
    plugins {
        id("org.jetbrains.kotlin.android") version "2.1.10" apply false
        id("com.android.application") version "8.1.2" apply false
        id("dev.flutter.flutter-plugin-loader")
    }
}

dependencyResolutionManagement {
    repositories {
        google()
        mavenCentral()
    }
}

val flutterSdkPath = run {
    val properties = java.util.Properties()
    file("local.properties").inputStream().use { properties.load(it) }
    properties.getProperty("flutter.sdk")
        ?: throw GradleException("flutter.sdk not set in local.properties")
}

includeBuild("$flutterSdkPath/packages/flutter_tools/gradle")

include(":app")