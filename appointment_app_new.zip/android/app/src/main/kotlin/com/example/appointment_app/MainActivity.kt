package com.example.appointment_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}