import 'package:appointment_app/Admin/home_admin.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class AdminLogin extends StatefulWidget {
  const AdminLogin({super.key});

  @override
  State<AdminLogin> createState() => _AdminLoginState();
}

class _AdminLoginState extends State<AdminLogin> {
   String email="",password="";

  TextEditingController passwordcontroller= new TextEditingController();
  TextEditingController mailcontroller = new TextEditingController();

 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff14141d),
      body: Container(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.asset("images/signin.png"),
            Padding(
              padding: const EdgeInsets.only(left:30.0,right: 30.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Welcome Back!",style: TextStyle(color: const Color.fromARGB(169, 255, 255, 255),fontSize: 32.0,fontWeight: FontWeight.w500),),
                     Text(
                    "AdminLogin",style: TextStyle(color: const Color.fromARGB(244, 255, 255, 255),fontSize: 25.0,fontWeight: FontWeight.bold),),
                    SizedBox(height: 90.0,),
                     Text(
                    "Email",style: TextStyle(color: const Color.fromARGB(162, 255, 255, 255),fontSize: 20.0,fontWeight: FontWeight.w500),),
                    TextField(
                                     style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 18.0),
                      controller: mailcontroller,
                      decoration: InputDecoration(hintText: "Enter Email",hintStyle: TextStyle(color: const Color.fromARGB(198, 255, 255, 255),),
                      suffixIcon: Icon(Icons.email,color: Colors.white,)
                      ),
                    ),
                     SizedBox(height: 40.0,),
                     Text(
                    "Password",style: TextStyle(color: const Color.fromARGB(162, 255, 255, 255),fontSize: 20.0,fontWeight: FontWeight.w500),),
                    TextField(
                                       style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 18.0),
                                       obscureText: true,
                      controller: passwordcontroller,
                      decoration: InputDecoration(hintText: "Enter Password",hintStyle: TextStyle(color: const Color.fromARGB(198, 255, 255, 255),),
                      suffixIcon: Icon(Icons.password,color: Colors.white,)
                      ),
                    ),
                    SizedBox(height: 20.0,),
                  
                    SizedBox(height: 60.0,),
                    GestureDetector(
                      onTap: ()async{
                        LoginAdmin();
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                         
                          Container(
                            width: 170,
                            padding: EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: const Color.fromARGB(240, 255, 255, 255),borderRadius: BorderRadius.circular(30)
                            ),
                            child: Center(child: Text("Login",style: TextStyle(
                              color: Color.fromARGB(248, 0, 0, 0),fontSize: 25.0,fontWeight: FontWeight.bold
                            ),),),
                          )
                        ],
                      ),
                    )
                ],
              ),
            )
          ],
          
        ),
      ),
    );
  }

  LoginAdmin(){
    FirebaseFirestore.instance.collection("Admin").get().then((snapshot){
      snapshot.docs.forEach((result){
        if(result.data()['id'] !=mailcontroller.text.trim()){
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(
              "Your id not correct",
              style: TextStyle(fontSize: 18.0),
            ),
          ));
        }else if(result.data()['password'] !=
          passwordcontroller.text.trim()){
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(
              "Your password is not correct",
              style: TextStyle(fontSize: 18.0),
            )));
          }else{
            Route route=MaterialPageRoute(builder: (context)=>HomeAdmin());
            Navigator.pushReplacement(context,route);          }
      });
    });
  }
}