import 'package:cloud_firestore/cloud_firestore.dart';

class DatabaseMethods{

  Future addUserInfo(Map<String,dynamic> userInfoMap,String Id )async{
   await FirebaseFirestore.instance.collection("users").doc(Id).set(userInfoMap);
  }
  Future addUserBooking(Map<String,dynamic> addBooking) async{
    await FirebaseFirestore.instance.collection("Bookings").add(addBooking);
  }
   Stream<QuerySnapshot> getAllBookings() {
    return FirebaseFirestore.instance.collection("Bookings").snapshots();
  }
  Future addBooking(Map<String, dynamic> userBookingMap, String id) async {
  return await FirebaseFirestore.instance
      .collection("bookings")
      .doc(id)
      .set(userBookingMap);
}
 Stream<QuerySnapshot> getAllbookings() {
    return FirebaseFirestore.instance
        .collection("Bookings")
        .orderBy("CreatedAt", descending: true)
        .snapshots();
  }
  Stream<QuerySnapshot> getUserBookings(String userId) {
  return FirebaseFirestore.instance
      .collection("bookings")
      .where("UserId", isEqualTo: userId)
      .orderBy("CreatedAt", descending: true)
      .snapshots();
}
}