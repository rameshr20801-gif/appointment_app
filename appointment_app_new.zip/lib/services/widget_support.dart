import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class Appwidget{
  static TextStyle headlineTextStyle(double size){
    return TextStyle(color:const Color.fromARGB(255, 11, 11, 11) ,fontWeight: FontWeight.bold,fontSize:size);
  }

    static TextStyle brownTextStyle(double size){
      return TextStyle(color:const Color.fromARGB(255, 127, 84, 84) ,fontSize: size,fontWeight: FontWeight.bold,);
  }
  
  static TextStyle greenTextStyle(double size){
      return TextStyle(color:const Color.fromARGB(255, 127, 84, 84) ,fontSize: size,fontWeight: FontWeight.bold,);
  }
}