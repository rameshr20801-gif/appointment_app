import 'package:appointment_app/services/database.dart';
import 'package:appointment_app/services/shared.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:firebase_auth/firebase_auth.dart';

class Booking extends StatefulWidget {
  final String service;
  const Booking({super.key, required this.service});

  @override
  State<Booking> createState() => _BookingState();
}

class _BookingState extends State<Booking> {
  String? name, id;

  Future<void> getUserInfo() async {
    name = await SharedPrefHelper().getUserName();
    id = await SharedPrefHelper().getUserId();
    print("User: $name, ID: $id");
    setState(() {});
  }

  @override
  void initState() {
    super.initState();
    getUserInfo();
  }

  int selectedDayIndex = 1;
  int? selectedTimeIndex;
  String? selectedTime;
  DateTime? selectedDate;

  final List<String> days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  final List<int> dates = [6, 7, 8, 9, 10, 11];

  final List<String> times = [
    "09:00 AM",
    "10:00 AM",
    "11:00 AM",
    "12:00 PM",
    "01:00 PM",
    "02:00 PM",
    "03:00 PM",
    "04:00 PM",
    "05:00 PM",
    "06:00 PM",
    "07:00 PM",
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.brown,
      appBar: AppBar(
        backgroundColor: Colors.brown,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Column(
        children: [
          // Profile Header
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(60),
                  child: Image.asset(
                    "images/gemini.png",
                    height: 100,
                    width: 100,
                  ),
                ),
                const SizedBox(width: 16),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const [
                    Divider(color: Color(0xFFFDECE7), thickness: 2.0),
                    Text(
                      "REGWAN",
                      style: TextStyle(
                        color: Color(0xFFDECCE7),
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1,
                      ),
                    ),
                    Text(
                      "HAIR ARTIST",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    Divider(color: Color(0xFFDECCE7), thickness: 2.0),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),

          // Slot Selection
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                "CHOOSE YOUR SLOT",
                style: TextStyle(
                  color: Colors.white.withOpacity(0.9),
                  fontWeight: FontWeight.bold,
                  fontSize: 22,
                ),
              ),
            ),
          ),
          const SizedBox(height: 15),

          // Day Selector
          SizedBox(
            height: 70,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: days.length,
              itemBuilder: (context, index) {
                bool isSelected = selectedDayIndex == index;
                return GestureDetector(
                  onTap: () {
                    setState(() {
                      selectedDayIndex = index;
                      selectedDate = DateTime.now()
                          .add(Duration(days: index)); // optional real date
                    });
                  },
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 8),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color:
                          isSelected ? const Color(0xFFFDECE7) : Colors.brown,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.white),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          days[index],
                          style: TextStyle(
                            color: isSelected ? Colors.black : Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 5),
                        Text(
                          dates[index].toString(),
                          style: TextStyle(
                            color: isSelected ? Colors.black : Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 20),

          // Time Selector
          Expanded(
            child: Container(
              width: double.infinity,
              decoration: const BoxDecoration(color: Color(0xFFF5F0E1)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Divider(color: Color(0xFF2C3925), thickness: 7),
                  const SizedBox(height: 10),
                  const Padding(
                    padding: EdgeInsets.only(left: 20),
                    child: Text(
                      "CHOOSE YOUR TIME",
                      style: TextStyle(
                        color: Colors.black87,
                        fontWeight: FontWeight.bold,
                        fontSize: 26,
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Expanded(
                    child: GridView.builder(
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 3,
                        childAspectRatio: 2.5,
                        crossAxisSpacing: 5,
                        mainAxisSpacing: 5,
                      ),
                      itemCount: times.length,
                      itemBuilder: (context, index) {
                        bool isSelected = selectedTimeIndex == index;
                        return GestureDetector(
                          onTap: () {
                            setState(() {
                              selectedTimeIndex = index;
                              selectedTime = times[index];
                            });
                          },
                          child: Container(
                            margin: const EdgeInsets.all(8),
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              color: isSelected
                                  ? const Color(0xFF2E3B2A)
                                  : Colors.white,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: const Color(0xFF2E3B2A)),
                            ),
                            child: Text(
                              times[index],
                              style: TextStyle(
                                color: isSelected
                                    ? Colors.white
                                    : const Color(0xFF2E3B2A),
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),

                  // Book Now Button
                  Center(
                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 20),
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF2E3B2A),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 50, vertical: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        onPressed: () async {
                          if (selectedTime != null) {
                            await makePayment("500");
                          } else {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text("Please select a time first"),
                              ),
                            );
                          }
                        },
                        child: const Text(
                          "BOOK NOW",
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// STRIPE PAYMENT  FIREBASE 
  Future<void> makePayment(String amount) async {
    try {
      var response = await http.post(
        Uri.parse('https://stripeserver-cz6x.onrender.com/create-checkout-session'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'items': [
            {'name': widget.service, 'price': int.parse(amount), 'quantity': 1}
          ]
        }),
      );

      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);

        if (responseData['url'] != null) {
          final uri = Uri.parse(responseData['url']);
          if (await canLaunchUrl(uri)) {
            await launchUrl(uri, mode: LaunchMode.externalApplication);

            // Save booking info
            final formattedDate = selectedDate != null
                ? DateFormat('EEEE, d MMM').format(selectedDate!)
                : 'No date selected';

            final formattedTime = selectedTime ?? 'No time selected';

            Map<String, dynamic> addBookingInfo = {
              "UserId": id,
              "Name": name,
              "Service": widget.service,
              "Amount": amount,
              "Id": id,
              "Date": formattedDate,
              "Time": formattedTime,
              "BookedOn": DateFormat('dd MMM yyyy').format(DateTime.now()),
              "CreatedAt": FieldValue.serverTimestamp(),
            };

            await DatabaseMethods().addUserBooking(addBookingInfo);

            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text("Booked Successfully!"),
                backgroundColor: Colors.green,
              ),
            );
          }
        } else {
          throw 'No checkout URL returned from backend';
        }
      } else {
        throw 'Failed to create checkout session';
      }
    } catch (e) {
      print('Error in makePayment: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Payment failed: $e')),
      );
    }
  }
}