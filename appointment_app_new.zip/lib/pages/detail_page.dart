import 'package:appointment_app/pages/booking.dart';
import 'package:appointment_app/services/database.dart';
import 'package:appointment_app/services/widget_support.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';
import 'package:firebase_auth/firebase_auth.dart';

class DetailPage extends StatefulWidget {
  final String service;
  const DetailPage({super.key, required this.service});

  @override
  State<DetailPage> createState() => _DetailPageState();
}

class _DetailPageState extends State<DetailPage> {
  TextEditingController nameController = TextEditingController();
  DateTime? selectedDate;
  TimeOfDay? selectedTime;
  bool isLoading = false;

  Future<void> _bookService() async {
    if (nameController.text.isEmpty || selectedDate == null || selectedTime == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fill all fields')),
      );
      return;
    }

    setState(() => isLoading = true);

    try {
      String id = const Uuid().v4();
      String formattedDate = DateFormat('dd MMM yyyy').format(selectedDate!);
      String formattedTime = selectedTime!.format(context);
       String? userId = FirebaseAuth.instance.currentUser?.uid;

      Map<String, dynamic> bookingData = {
        "Id": id,
        "Name": nameController.text,
        "Service": widget.service,
        "Date": formattedDate,
        "Time": formattedTime,
        "Amount": "299",
        "BookedOn": DateFormat('dd MMM yyyy').format(DateTime.now()),
        "CreatedAt": FieldValue.serverTimestamp(),
      };

      await DatabaseMethods().addBooking(bookingData, id);

      // Navigate to Booking Page
      Navigator.pushReplacement(
  context,
  MaterialPageRoute(builder: (context) => Booking(service: widget.service)),
);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Booking successful!')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }

    setState(() => isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.brown[50],
      appBar: AppBar(
        backgroundColor: Colors.brown,
        title: Text(widget.service, style: const TextStyle(color: Colors.white)),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Book your ${widget.service}",
                style: Appwidget.brownTextStyle(24.0)),
            const SizedBox(height: 30),
            TextField(
              controller: nameController,
              decoration: InputDecoration(
                labelText: "Your Name",
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              ),
            ),
            const SizedBox(height: 20),
            ListTile(
              title: Text(selectedDate == null
                  ? "Select Date"
                  : "Date: ${DateFormat('dd MMM yyyy').format(selectedDate!)}"),
              trailing: const Icon(Icons.calendar_month, color: Colors.brown),
              onTap: () async {
                DateTime? picked = await showDatePicker(
                  context: context,
                  initialDate: DateTime.now(),
                  firstDate: DateTime.now(),
                  lastDate: DateTime(2100),
                );
                if (picked != null) {
                  setState(() => selectedDate = picked);
                }
              },
            ),
            ListTile(
              title: Text(selectedTime == null
                  ? "Select Time"
                  : "Time: ${selectedTime!.format(context)}"),
              trailing: const Icon(Icons.access_time, color: Colors.brown),
              onTap: () async {
                TimeOfDay? picked = await showTimePicker(
                  context: context,
                  initialTime: TimeOfDay.now(),
                );
                if (picked != null) {
                  setState(() => selectedTime = picked);
                }
              },
            ),
            const SizedBox(height: 40),
            Center(
              child: ElevatedButton(
                onPressed: isLoading ? null : _bookService,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.brown,
                  padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: isLoading
                    ? const CircularProgressIndicator(color: Colors.white)
                    : const Text("Book Now",
                        style: TextStyle(color: Colors.white, fontSize: 18)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}