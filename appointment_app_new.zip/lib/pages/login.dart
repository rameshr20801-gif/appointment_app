import 'package:appointment_app/Admin/admin_login.dart';
import 'package:appointment_app/pages/bottomnav.dart';
import 'package:appointment_app/pages/signup.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
      String email="",password="";

  TextEditingController passwordcontroller= new TextEditingController();
  TextEditingController mailcontroller = new TextEditingController();

  userLogin() async{
    try{
      await FirebaseAuth.instance
        .signInWithEmailAndPassword(email: email!, password: password!);

        Navigator.push(context,MaterialPageRoute(builder: (context)=>Bottomnav()));
    }
    on FirebaseAuthException catch(e) {
      if (e.code == 'User-not-found'){
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          backgroundColor:Colors.red,
          content:Text(
            "No user found for the Email",
            style: TextStyle(fontSize: 16.0,color: Colors.white),
          )
        ));

      }else if (e.code == 'Wrong-password'){
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          backgroundColor: Colors.red,
          content: Text(
            "Wrong password provided by User",style: TextStyle(fontSize: 16.0,color: Colors.white),
          ),
        ));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff14141d),
      body: Container(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.asset("images/signin.png"),
            Padding(
              padding: const EdgeInsets.only(left:30.0,right: 30.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Welcome!",style: TextStyle(color: const Color.fromARGB(169, 255, 255, 255),fontSize: 32.0,fontWeight: FontWeight.w500),),
                     Text(
                    "LogIn",style: TextStyle(color: const Color.fromARGB(244, 255, 255, 255),fontSize: 45.0,fontWeight: FontWeight.bold),),
                    SizedBox(height: 90.0,),
                     Text(
                    "Email",style: TextStyle(color: const Color.fromARGB(162, 255, 255, 255),fontSize: 20.0,fontWeight: FontWeight.w500),),
                    TextField(
                                     style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 18.0),
                      controller: mailcontroller,
                      decoration: InputDecoration(hintText: "Enter Email",hintStyle: TextStyle(color: const Color.fromARGB(198, 255, 255, 255),),
                      suffixIcon: Icon(Icons.email,color: Colors.white,)
                      ),
                    ),
                     SizedBox(height: 40.0,),
                     Text(
                    "Password",style: TextStyle(color: const Color.fromARGB(162, 255, 255, 255),fontSize: 20.0,fontWeight: FontWeight.w500),),
                    TextField(
                                       style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 18.0),
                                       obscureText: true,
                      controller: passwordcontroller,
                      decoration: InputDecoration(hintText: "Enter Password",hintStyle: TextStyle(color: const Color.fromARGB(198, 255, 255, 255),),
                      suffixIcon: Icon(Icons.password,color: Colors.white,)
                      ),
                    ),
                    SizedBox(height: 20.0,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                         Text(
                    "Forget Password?",style: TextStyle(color:Color(0xff6b63ff),fontSize: 18.0,fontWeight: FontWeight.w500),),
                      ],
                    ),
                    SizedBox(height: 60.0,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        GestureDetector(
                          onTap: () async{
                            Navigator.push(context, MaterialPageRoute(builder: (context)=>Signup()));
                          },
                          child: Container(
                            width: 170,
                            padding: EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: const Color.fromARGB(245, 255, 255, 255),borderRadius: BorderRadius.circular(30)
                            ),
                            child: Center(child: Text("Sign Up",style: TextStyle(
                              color: Color.fromARGB(244, 3, 3, 3),fontSize: 25.0,fontWeight: FontWeight.bold
                            ),),),
                          ),
                        ),
                        Container(
                          width: 170,
                          padding: EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: const Color.fromARGB(240, 255, 255, 255),borderRadius: BorderRadius.circular(30)
                          ),
                          child: Center(child: Text("Login",style: TextStyle(
                            color: Color.fromARGB(248, 0, 0, 0),fontSize: 25.0,fontWeight: FontWeight.bold
                          ),),),
                        )
                      ],
                    ),
                    SizedBox(height: 20.0,),
                    GestureDetector(
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>AdminLogin()));
                      },
                      child: Center(
                        child: Text("Admin Panel",style: TextStyle(
                                color: Color.fromARGB(248, 255, 255, 255),fontSize: 25.0,fontWeight: FontWeight.bold
                              ),),
                      ),
                    ),
                ],
              ),
            )
          ],
          
        ),
      ),
    );
  }
}