import 'package:appointment_app/services/widget_support.dart';
import 'package:flutter/material.dart';

class Onboarding extends StatefulWidget {
  const Onboarding({super.key});

  @override
  State<Onboarding> createState() => _OnboardingState();
}

class _OnboardingState extends State<Onboarding> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Column(
          children: [
            Image.asset("images/wallpaper.png",height: 650,),
            Expanded(
              child: Container(
                padding: EdgeInsets.only(left: 20.0,right: 20.0),
                width: MediaQuery.of(context).size.width,
                decoration: BoxDecoration(color: Color.fromARGB(255, 8, 8, 8),),
                child: Column(children: [
                  SizedBox(height: 30.0,),
                  Text("set your time, and we’ll handle the rest",style: TextStyle(color: Colors.white,fontWeight: FontWeight.w600,fontSize: 21.0),),
                  SizedBox(height: 30.0,),
                  Material(
                    elevation: 5.0,
                    borderRadius: BorderRadius.circular(5),
                    child: Container(
                      height: 60,
                      width: 150,
                      padding: EdgeInsets.all(10),
                      decoration: BoxDecoration(color: Color.fromARGB(255, 251, 250, 250),borderRadius: BorderRadius.circular(5)),child: Center(child: Text("BOOK NOW",style: Appwidget.headlineTextStyle(20.0),)),
                    ),
                  )
                ],),
              ),
            )
          ],
        ),
      ),
    );
  }
}