import 'package:appointment_app/pages/login.dart';
import 'package:appointment_app/services/auth.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:appointment_app/pages/my_bookings.dart';

class Profile extends StatefulWidget {
  const Profile({super.key});

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  final String userId = FirebaseAuth.instance.currentUser?.uid ?? "";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.brown,
      body: Container(
        margin: const EdgeInsets.only(top: 50.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            const Padding(
              padding: EdgeInsets.only(left: 20.0),
              child: Text(
                "PROFILE",
                style: TextStyle(
                  color: Color(0xFFF5F0E1),
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(height: 20.0),

            // Profile section
            Expanded(
              child: Container(
                decoration: const BoxDecoration(
                  color: Colors.white,
                ),
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 0.0),
                        child: Divider(
                          color: Colors.brown,
                          thickness: 4.0,
                        ),
                      ),
                      const SizedBox(height: 20.0),

                      // Profile image
                      const CircleAvatar(
                        radius: 65,
                        backgroundColor: Color(0xff2c3925),
                        backgroundImage:
                            AssetImage("images/gemini.png"),
                      ),
                      const SizedBox(height: 25.0),

                      // Name card
                      _buildInfoCard(
                        icon: Icons.person,
                        title: "NAME",
                        value: "RAMESH",
                      ),
                      const SizedBox(height: 25.0),

                      // Email card
                      _buildInfoCard(
                        icon: Icons.mail,
                        title: "EMAIL",
                        value: "ramesh123@gmail.com",
                      ),
                      const SizedBox(height: 25.0),
                     GestureDetector(
  onTap: () {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => MyBookingsPage(userId: userId),
      ),
    );
  },
  child: _buildActionCard(
    icon: Icons.calendar_today,
    label: "My Bookings",
  ),
),
 SizedBox(height: 25.0),

                      // Logout button
                      GestureDetector(
                        onTap: () {
                          AuthMethods().SignOut();
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(builder: (context) => const Login()),
                          );
                        },
                        child: _buildActionCard(
                          icon: Icons.logout,
                          label: "Logout",
                        ),
                      ),
                      const SizedBox(height: 25.0),

                      // Delete Account button
                      GestureDetector(
                        onTap: () {
                          AuthMethods().deleteuser();
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(builder: (context) => const Login()),
                          );
                        },
                        child: _buildActionCard(
                          icon: Icons.delete,
                          label: "Delete Account",
                        ),
                      ),
                      const SizedBox(height: 40.0),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // 🔹 Common widget for user info
  Widget _buildInfoCard({
    required IconData icon,
    required String title,
    required String value,
  }) {
    return Container(
      padding: const EdgeInsets.only(left: 20.0),
      height: 70.0,
      margin: const EdgeInsets.symmetric(horizontal: 20.0),
      width: MediaQuery.of(context).size.width,
      decoration: BoxDecoration(
        color: const Color(0xff2c3925),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        children: [
          Icon(icon, color: Colors.white, size: 40.0),
          const SizedBox(width: 20.0),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  color: Color.fromARGB(255, 248, 210, 210),
                  fontSize: 15.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                value,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 20.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // 🔹 Common widget for logout & delete buttons
  Widget _buildActionCard({
    required IconData icon,
    required String label,
  }) {
    return Container(
      padding: const EdgeInsets.only(left: 20.0),
      height: 70.0,
      margin: const EdgeInsets.symmetric(horizontal: 20.0),
      width: MediaQuery.of(context).size.width,
      decoration: BoxDecoration(
        color: const Color(0xff2c3925),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        children: [
          Icon(icon, color: Colors.white, size: 40.0),
          const SizedBox(width: 20.0),
          Text(
            label,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 20.0,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}