import 'package:appointment_app/pages/bottomnav.dart';
import 'package:appointment_app/pages/home.dart';
import 'package:appointment_app/pages/login.dart';
import 'package:appointment_app/services/database.dart';
import 'package:appointment_app/services/shared.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:random_string/random_string.dart';

class Signup extends StatefulWidget {
  const Signup({super.key});

  @override
  State<Signup> createState() => _SignupState();
}

class _SignupState extends State<Signup> {

String email="",password="",name="";
TextEditingController namecontroller= new TextEditingController();
TextEditingController passwordcontroller= new TextEditingController();
TextEditingController mailcontroller= new TextEditingController();

final _Formkey=GlobalKey<FormState>();

registration() async {
  if (password != null && 
      namecontroller.text.isNotEmpty && 
      mailcontroller.text.isNotEmpty) {
    try {
      UserCredential userCredential = await FirebaseAuth.instance
          .createUserWithEmailAndPassword(
              email: mailcontroller.text.trim(),
              password: password!.trim(),
          );
          String Id=randomAlphaNumeric(10);
          Map<String,dynamic>userInfoMap={
            "Name":namecontroller.text,
            "Email":namecontroller.text,
            "Id":namecontroller.text,
          };
          await DatabaseMethods().addUserInfo(userInfoMap, Id);
          await SharedPrefHelper().saveUserId(Id);
          await SharedPrefHelper().saveUserName(namecontroller.text);
          await SharedPrefHelper().saveUserEmail(mailcontroller.text);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            "Registered Successfully",
            style: TextStyle(fontSize: 20.0),
          ),
          backgroundColor: Colors.green,
        ),
      );

      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => Bottomnav()),
      );
    } on FirebaseAuthException catch (e) {
      if (e.code == 'weak-password') {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            backgroundColor: Colors.amberAccent,
            content: Text(
              "Password provided is too weak",
              style: TextStyle(fontSize: 18.0),
            ),
          ),
        );
      } else if (e.code == 'email-already-in-use') {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            backgroundColor: Colors.amberAccent,
            content: Text(
              "Account already exists",
              style: TextStyle(fontSize: 18.0),
            ),
          ),
        );
      }
    } catch (e) {
     
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: Colors.redAccent,
          content: Text(
            "Error: ${e.toString()}",
            style: TextStyle(fontSize: 18.0),
          ),
        ),
      );
    }
  } else {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: Colors.orangeAccent,
        content: Text(
          "Please fill all fields",
          style: TextStyle(fontSize: 18.0),
        ),
      ),
    );
  }
}


  @override
  Widget build(BuildContext context) {
    return Scaffold(
       backgroundColor: Color(0xff14141d),
      body: GestureDetector(
        onTap: (){
          if(_Formkey.currentState!.validate()){
            setState(() {
              email=mailcontroller.text;
              name=namecontroller.text;
              password=passwordcontroller.text;
            });
          }
          registration();
        },
        child: Container(
          child: Form(
            key: _Formkey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Image.asset("images/signin.png"),
                Padding(
                  padding: const EdgeInsets.only(left:30.0,right: 30.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                     
                         Text(
                        "Sign Up",style: TextStyle(color: const Color.fromARGB(244, 255, 255, 255),fontSize: 45.0,fontWeight: FontWeight.bold),),
                        SizedBox(height: 35.0,),
                         Text(
                        "Name",style: TextStyle(color: const Color.fromARGB(162, 255, 255, 255),fontSize: 20.0,fontWeight: FontWeight.w500),),
                        TextFormField(
                          validator:(value){
                            if (value==null||value.isEmpty){
                              return 'Please Enter Name';
                            }
                            return null;
                          } ,
                          style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 18.0),
                          controller: namecontroller,
                          decoration: InputDecoration(hintText: "Enter Name",hintStyle: TextStyle(color: const Color.fromARGB(198, 255, 255, 255),),
                          suffixIcon: Icon(Icons.person_outlined,color: Colors.white,)
                          ),
                        ),
                         SizedBox(height: 40.0,),
                          Text(
                        "Email",style: TextStyle(color: const Color.fromARGB(162, 255, 255, 255),fontSize: 20.0,fontWeight: FontWeight.w500),),
                        TextFormField(
                          validator:(value){
                            if (value==null||value.isEmpty){
                              return 'Please Enter Mail';
                            }
                            return null;
                          } ,
                           style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 18.0),
                          controller: mailcontroller,
                          decoration: InputDecoration(hintText: "Enter Email",hintStyle: TextStyle(color: const Color.fromARGB(198, 255, 255, 255),),
                          suffixIcon: Icon(Icons.email,color: Colors.white,)
                          ),
                        ),
                         SizedBox(height: 40.0,),
                         Text(
                        "Password",style: TextStyle(color: const Color.fromARGB(162, 255, 255, 255),fontSize: 20.0,fontWeight: FontWeight.w500),),
                        TextFormField(
                          validator:(value){
                            if (value==null||value.isEmpty){
                              return 'Please Enter Password';
                            }
                            return null;
                          } ,
                          style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 18.0),
                          controller: passwordcontroller,
                          decoration: InputDecoration(hintText: "Enter Password",hintStyle: TextStyle(color: const Color.fromARGB(198, 255, 255, 255),),
                          suffixIcon: Icon(Icons.password,color: Colors.white,)
                          ),
                        ),
                        SizedBox(height: 40.0,),
                         Text(
                        "Confirm Password",style: TextStyle(color: const Color.fromARGB(162, 255, 255, 255),fontSize: 20.0,fontWeight: FontWeight.w500),),
                        TextFormField(
                           validator:(value){
                            if (value==null||value.isEmpty){
                              return 'Please Enter Password';
                            }
                            return null;
                          } ,
                          style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 18.0),
                          controller: passwordcontroller,
                          decoration: InputDecoration(hintText: "Enter Password",hintStyle: TextStyle(color: const Color.fromARGB(198, 255, 255, 255),),
                          suffixIcon: Icon(Icons.password,color: Colors.white,)
                          ),
                        ),
                       
                        SizedBox(height: 40.0,),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              width: 170,
                              padding: EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: const Color.fromARGB(245, 255, 255, 255),borderRadius: BorderRadius.circular(30)
                              ),
                              child: GestureDetector(
                                onTap: (){
                                  if(mailcontroller.text!=""&&namecontroller.text!=""&&passwordcontroller.text!=""){
                                    setState(() {
                                      name=namecontroller.text;
                                      email=mailcontroller.text;
                                      password=passwordcontroller.text;
                                    });

                                    registration();
                                  }
                                },

                                child: Center(child: Text("Sign Up",style: TextStyle(
                                  color: Color.fromARGB(244, 3, 3, 3),fontSize: 25.0,fontWeight: FontWeight.bold
                                ),),),
                              ),
                            ),
                           
                          ],
                        ),
                        SizedBox(height: 17.0,),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                         Text(
                        "Already have an account?",style: TextStyle(color: const Color.fromARGB(162, 255, 255, 255),fontSize: 20.0,fontWeight: FontWeight.w500),),
                         GestureDetector(
                          onTap: (){
                            Navigator.push(context, MaterialPageRoute(builder: (context)=>Login()));
                          },
                           child: Text(
                                               "LogIn",style: TextStyle(color:Colors.white,fontSize: 20.0,fontWeight: FontWeight.w500),),
                         ),
            
                        ],)
                    ],
                  ),
                )
              ],
              
            ),
          ),
        ),
      ),
    );
  }
}