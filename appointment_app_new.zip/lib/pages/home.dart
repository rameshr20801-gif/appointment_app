import 'package:appointment_app/pages/detail_page.dart';
import 'package:appointment_app/services/widget_support.dart';
import 'package:flutter/material.dart';
import 'package:appointment_app/pages/my_bookings.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:Color.fromARGB(255, 251, 250, 250),
      body: SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.only(top: 50.0,),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
        Text("GOOD MORNING",style: TextStyle(color:Colors.brown,fontSize: 22.0,fontWeight: FontWeight.w500),),
        Text("Folks",style: TextStyle(color:Colors.brown,fontSize: 40.0,fontWeight: FontWeight.bold),),
        Padding(
          padding: const EdgeInsets.only(right: 120.0),
          child: Divider(color:Colors.brown ,thickness: 4.0,),
        ),
        SizedBox(height: 10.0),
        Text("Need a quick trim or a full restyle?\nWe’ve got you covered",style: TextStyle(color: Colors.brown,fontWeight: FontWeight.w600,fontSize: 18.0),),
        SizedBox(height: 10.0,),
        Container(
            width: MediaQuery.of(context).size.width,
            decoration: BoxDecoration(color: Color.fromARGB(255, 251, 250, 250)),
            child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
        Divider(color: Colors.brown,thickness: 8.0,),
        SizedBox(height: 10.0,),
        Padding(
          padding: const EdgeInsets.only(left: 18.0),
          child: Text("SERVICES",style: Appwidget.brownTextStyle(26.0)),
        ),
        SizedBox(height: 20.0),
        GestureDetector(
          onTap: (){
            Navigator.push(context, MaterialPageRoute(builder: (context)=>DetailPage(service: "HAIR CUT")));
          },
          child: Padding(
            padding: const EdgeInsets.only(left: 20.0),
            child: Row(
              children: [
                Container(
                  padding: EdgeInsets.all(2),
                  decoration: BoxDecoration(color:Colors.white,border: Border.all(color: const Color.fromARGB(255, 123, 90, 90),width: 7.0),borderRadius: BorderRadius.circular(10)),
                  child: Container(
                    padding: EdgeInsets.all(18),
                    decoration: BoxDecoration(color:Colors.brown,borderRadius: BorderRadius.circular(10)),
                    child: Image.asset("images/outline.png",height: 50,width: 50,fit: BoxFit.cover,color:const Color.fromARGB(255, 255, 255, 255),),
                  ),
                ),
                SizedBox(width: 20.0,),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                     Text("HAIR CUT",style: Appwidget.brownTextStyle(22.0),),
                     SizedBox(height: 10.0,),
                     Text("slick Back Style, Caesar Cut, Low Fade,\nHigh Fade, Skin Fade,Burst Fade",style: TextStyle(color: const Color.fromARGB(255, 95, 93, 92),fontWeight: FontWeight.w600,fontSize: 13.0),),
          
                  ],
                )
               
              ],
            ),
          ),
        ),
        SizedBox(height: 10.0,),
        Padding(
          padding: const EdgeInsets.only(left: 20.0,right: 20.0),
          child: Divider(color: Colors.brown,thickness: 4.0,),
        ),
        SizedBox(height: 20.0),
        Padding(
          padding: const EdgeInsets.only(left: 20.0),
          child: Row(
            children: [
              Container(
                padding: EdgeInsets.all(2),
                decoration: BoxDecoration(color:Colors.white,border: Border.all(color: const Color.fromARGB(255, 123, 90, 90),width: 7.0),borderRadius: BorderRadius.circular(10)),
                child: Container(
                  padding: EdgeInsets.all(18),
                  decoration: BoxDecoration(color:Colors.brown,borderRadius: BorderRadius.circular(10)),
                  child: Image.asset("images/outline.png",height: 50,width: 50,fit: BoxFit.cover,color:const Color.fromARGB(255, 255, 255, 255),),
                ),
              ),
              SizedBox(width: 20.0,),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                   Text("HAIR TREATMENT",style: Appwidget.brownTextStyle(22.0),),
                   SizedBox(height: 10.0,),
                   Text("Keratin Treatment, Smoothening\nRebonding, Scalp Treatment",style: TextStyle(color: const Color.fromARGB(255, 95, 93, 92),fontWeight: FontWeight.w600,fontSize: 13.0),),
        
                ],
              )
             
            ],
          ),
        ),
        SizedBox(height: 10.0,),
        Padding(
          padding: const EdgeInsets.only(left: 20.0,right: 20.0),
          child: Divider(color: Colors.brown,thickness: 4.0,),
        ),
        SizedBox(height: 20.0),
        Padding(
          padding: const EdgeInsets.only(left: 20.0),
          child: Row(
            children: [
              Container(
                padding: EdgeInsets.all(2),
                decoration: BoxDecoration(color:Colors.white,border: Border.all(color: const Color.fromARGB(255, 123, 90, 90),width: 7.0),borderRadius: BorderRadius.circular(10)),
                child: Container(
                  padding: EdgeInsets.all(18),
                  decoration: BoxDecoration(color:Colors.brown,borderRadius: BorderRadius.circular(10)),
                  child: Image.asset("images/outline.png",height: 50,width: 50,fit: BoxFit.cover,color:const Color.fromARGB(255, 255, 255, 255),),
                ),
              ),
              SizedBox(width: 20.0,),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                   Text("COMBO PACKS",style: Appwidget.brownTextStyle(22.0),),
                   SizedBox(height: 10.0,),
                   Text("Haircut + Beard Trim,Grooming Package,\nHaircut + Hair Wash + Style",style: TextStyle(color: const Color.fromARGB(255, 95, 93, 92),fontWeight: FontWeight.w600,fontSize: 13.0),),
        
                ],
              )
             
            ],
          ),
        ),
        SizedBox(height: 10.0,),
        Padding(
          padding: const EdgeInsets.only(left: 20.0,right: 20.0),
          child: Divider(color: Colors.brown,thickness: 4.0,),
        ),
        SizedBox(height: 20.0),
        Padding(
          padding: const EdgeInsets.only(left: 20.0),
          child: Row(
            children: [
              Container(
                padding: EdgeInsets.all(2),
                decoration: BoxDecoration(color:Colors.white,border: Border.all(color: const Color.fromARGB(255, 123, 90, 90),width: 7.0),borderRadius: BorderRadius.circular(10)),
                child: Container(
                  padding: EdgeInsets.all(18),
                  decoration: BoxDecoration(color:Colors.brown,borderRadius: BorderRadius.circular(10)),
                  child: Image.asset("images/outline.png",height: 50,width: 50,fit: BoxFit.cover,color:const Color.fromARGB(255, 255, 255, 255),),
                ),
              ),
              SizedBox(width: 20.0,),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                   Text("SPA & RELAXATION",style: Appwidget.brownTextStyle(22.0),),
                   SizedBox(height: 10.0,),
                   Text("Head Massage, Hair Oil Massage,\n Dandruff Treatment, Steam Therapy",style: TextStyle(color: const Color.fromARGB(255, 95, 93, 92),fontWeight: FontWeight.w600,fontSize: 13.0),),
        
                ],
              )
             
            ],
          ),
        ),
        SizedBox(height: 10.0,),
        Padding(
          padding: const EdgeInsets.only(left: 20.0,right: 20.0),
          child: Divider(color: Colors.brown,thickness: 4.0,),
        ),
            ],),
          ),
        
          ],),
          
        ),
      ),
    );
  }
}